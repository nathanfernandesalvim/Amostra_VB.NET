﻿Namespace meuProjeto1.Models

    Public Class Amostra

        Public Property Id As Integer
        Public Property Nome As String
        Public Property Diametro As Double
        Public Property Area As Double

    End Class

End Namespace