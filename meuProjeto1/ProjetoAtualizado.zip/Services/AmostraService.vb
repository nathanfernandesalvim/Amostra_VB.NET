﻿Imports meuProjeto1.Models
Imports meuProjeto1.Data

Public Class AmostraService

    Private ReadOnly _repositorio As ManipularAmostrasNoBanco

    Public Sub New()
        Dim conexao = New CriarConexaoBanco()
        _repositorio = New ManipularAmostrasNoBanco(conexao)
    End Sub

    Public Function CalcularArea(diametro As Double) As Double
        If diametro <= 0 Then Return 0
        Return Math.PI * Math.Pow(diametro / 2, 2)
    End Function

    Public Function CriarAmostra(nome As String, diametro As Double) As Amostra
        Dim area = CalcularArea(diametro)

        Return New Amostra With {
            .Nome = nome,
            .Diametro = diametro,
            .Area = area
        }
    End Function

    Public Function AtualizarAmostra(id As Integer, nome As String, diametro As Double) As Amostra
        Dim area = CalcularArea(diametro)

        Return New Amostra With {
            .Id = id,
            .Nome = nome,
            .Diametro = diametro,
            .Area = area
        }

    End Function

    Public Sub DeletarAmostra(id As Integer)
        _repositorio.Deletar(id)
    End Sub

    Public Function BuscarAmostraPorId(id As Integer) As Amostra
        Return _repositorio.LerAmostra(id)
    End Function

    Public Function BuscarPrimeiroRegistro() As Amostra
        Return _repositorio.ObterPrimeiroRegistro()
    End Function

End Class
